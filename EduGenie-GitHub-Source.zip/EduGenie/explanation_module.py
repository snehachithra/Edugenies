import os

from gemini_client import generate

_LOCAL_PIPELINE = None


def _get_local_explainer():
    global _LOCAL_PIPELINE
    if _LOCAL_PIPELINE is not None:
        return _LOCAL_PIPELINE

    # Optional local model. Install the [local] dependencies to enable it.
    from transformers import pipeline

    model_name = os.getenv("LOCAL_EXPLANATION_MODEL", "MBZUAI/LaMini-Flan-T5-783M")
    _LOCAL_PIPELINE = pipeline("text2text-generation", model=model_name)
    return _LOCAL_PIPELINE


def explain_concept(topic: str) -> str:
    # Set USE_LOCAL_EXPLAINER=true to use the LaMini-Flan-T5 model.
    if os.getenv("USE_LOCAL_EXPLAINER", "false").lower() == "true":
        try:
            pipe = _get_local_explainer()
            prompt = (
                "Explain this educational concept simply for a beginner. "
                "Use a short definition, an intuitive explanation, and one example: "
                f"{topic}"
            )
            result = pipe(prompt, max_new_tokens=220, do_sample=False)
            return result[0]["generated_text"].strip()
        except Exception as exc:
            return f"Local explanation model could not be loaded: {exc}"

    prompt = f"""
Explain the following educational concept for a beginner.
Keep it clear and concise. Include:
1. A simple definition
2. How it works
3. One easy example

Concept:
{topic}
"""
    try:
        return generate(prompt)
    except Exception as exc:
        return f"Unable to generate an explanation right now: {exc}"
