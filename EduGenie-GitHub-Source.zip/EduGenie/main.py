import os
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from qna import answer_question
from explanation_module import explain_concept
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

load_dotenv()

app = FastAPI(title="EduGenie", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class TextRequest(BaseModel):
    text: str


class QARequest(BaseModel):
    question: str


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/qa")
async def qa(payload: QARequest):
    return JSONResponse({"result": answer_question(payload.question)})


@app.post("/explain")
async def explain(payload: TextRequest):
    return JSONResponse({"result": explain_concept(payload.text)})


@app.post("/quiz")
async def quiz(payload: TextRequest):
    return JSONResponse({"result": generate_quiz(payload.text)})


@app.post("/summarize")
async def summarize(payload: TextRequest):
    return JSONResponse({"result": summarize_text(payload.text)})


@app.post("/learn/recommendations")
async def recommendations(payload: TextRequest):
    return JSONResponse({"result": get_learning_recommendations(payload.text)})


@app.get("/health")
async def health():
    return {"status": "ok", "gemini_configured": bool(os.getenv("GEMINI_API_KEY"))}
