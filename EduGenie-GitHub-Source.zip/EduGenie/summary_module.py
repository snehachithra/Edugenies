from gemini_client import generate


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational text for quick revision.
Keep the key facts and ideas, remove repetition, and use simple language.
Prefer a short paragraph followed by 3-6 bullet points when useful.

Text:
{text}
"""
    try:
        return generate(prompt)
    except Exception as exc:
        return f"Unable to summarize right now: {exc}"
