from gemini_client import generate


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a personalized learning path for the topic below.

Organize it from beginner to advanced. Include:
- Prerequisites
- Beginner topics
- Intermediate topics
- Advanced topics
- A suggested 4-week timeline
- Practice ideas
- Useful resource types (videos, articles, books, documentation)
- A short checkpoint after each stage

Topic:
{topic}
"""
    try:
        return generate(prompt)
    except Exception as exc:
        return f"Unable to create a learning path right now: {exc}"
