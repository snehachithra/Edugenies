from gemini_client import generate


def answer_question(question: str) -> str:
    prompt = f"""
You are EduGenie, a friendly educational assistant.
Answer the student's question accurately and concisely.
Use simple language appropriate for a learner.
If the question is ambiguous, state the assumption you are making.

Student question:
{question}
"""
    try:
        return generate(prompt)
    except Exception as exc:
        return f"Unable to answer right now: {exc}"
