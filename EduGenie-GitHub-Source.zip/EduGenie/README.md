# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight AI educational assistant based on the supplied project specification. It provides:

- Question answering
- Simple concept explanations
- Three-question MCQ quiz generation
- Text summarization
- Beginner-to-advanced learning recommendations
- A responsive HTML/CSS interface
- FastAPI REST endpoints

The project specification describes a FastAPI backend, HTML/CSS frontend, Gemini for Q&A/summarization/quiz/learning paths, and LaMini-Flan-T5 as the lightweight local explanation option.

## Project structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── requirements-local.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## 1. Requirements

- Python 3.10+
- A Google Gemini API key
- Internet access for Gemini API calls

The original specification also lists FastAPI, Uvicorn and Jinja2 as prerequisites.

## 2. Create a virtual environment

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

For the optional local LaMini-Flan-T5 explanation model:

```bash
pip install -r requirements-local.txt
```

## 4. Configure Gemini

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

On Windows:

```powershell
copy .env.example .env
```

Then set:

```env
GEMINI_API_KEY=your_real_key
```

Never commit `.env` or your API key to GitHub.

## 5. Run

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

The API health endpoint is:

```text
http://127.0.0.1:8000/health
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/qa` | Answer a question |
| POST | `/explain` | Explain a concept |
| POST | `/quiz` | Generate 3 MCQs |
| POST | `/summarize` | Summarize text |
| POST | `/learn/recommendations` | Generate a learning path |
| GET | `/health` | Server/configuration health |

Example request:

```bash
curl -X POST http://127.0.0.1:8000/qa \
  -H "Content-Type: application/json" \
  -d "{\"question\":\"What is photosynthesis?\"}"
```

## GitHub upload

After extracting this ZIP:

```bash
git init
git add .
git commit -m "Initial EduGenie project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/EduGenie.git
git push -u origin main
```

Or create a repository on GitHub and upload the project files through the GitHub web interface.

## Notes

- The application uses the current `google-genai` Python SDK.
- The default Gemini model is configurable through `GEMINI_MODEL`.
- The quiz endpoint validates the model's JSON structure before returning it.
- The optional local explanation model follows the project's LaMini-Flan-T5 concept; because its dependencies are large, they are kept in `requirements-local.txt`.
- API keys are read from environment variables and are not stored in source code.

## Original project alignment

The source specification defines the modules `main.py`, `explanation_module.py`, `qna.py`, `quiz_module.py`, `summary_module.py`, and `learning_path.py`, with `/qa`, `/explain`, `/quiz`, `/summarize`, and `/learn/recommendations` endpoints. This implementation preserves that organization while adding configuration, validation, error handling, and a ready-to-run frontend.
