import json
import re

from gemini_client import generate


def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(passage: str):
    prompt = f"""
Create exactly 3 multiple-choice questions from the educational passage below.

Return ONLY valid JSON in this exact shape:
[
  {{
    "question": "Question text",
    "options": ["A", "B", "C", "D"],
    "answer": "The exact correct option text"
  }}
]

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- One correct answer per question.
- Questions must be answerable from the passage.
- Do not include Markdown or extra text.

Passage:
{passage}
"""
    try:
        raw = clean_json_block(generate(prompt))
        data = json.loads(raw)
        if not isinstance(data, list) or len(data) != 3:
            raise ValueError("Gemini did not return exactly 3 questions.")
        for item in data:
            if not all(k in item for k in ("question", "options", "answer")):
                raise ValueError("Quiz item is missing a required field.")
            if len(item["options"]) != 4:
                raise ValueError("Each question must contain 4 options.")
        return data
    except Exception as exc:
        return {"error": f"Quiz generation failed: {exc}"}
